import base64
import logging
from typing import List, Dict, Any, Optional
from pathlib import Path
import json

from openai import OpenAI
import cv2
import numpy as np
from pdf2image import convert_from_path
from PIL import Image
import pytesseract

from app.core.config import settings
from app.models.document import ProcessingStatus
from app.db.database import SessionLocal

logger = logging.getLogger(__name__)

class DocumentProcessor:
    def __init__(self):
        self.openai_client = OpenAI(api_key=settings.OPENAI_API_KEY)
        self.preprocessing = ImagePreprocessor()
        
    async def process_pdf(self, pdf_path: str, schema: Optional[Dict] = None) -> Dict[str, Any]:
        """Process a PDF document and extract data using GPT-4o with memory optimization"""
        try:
            # Get page count first without loading all images
            page_count = self._get_page_count(pdf_path)
            logger.info(f"Processing PDF with {page_count} pages")

            # Process pages in chunks to manage memory
            chunk_size = 3  # Process 3 pages at a time
            extracted_data = []

            for chunk_start in range(0, page_count, chunk_size):
                chunk_end = min(chunk_start + chunk_size, page_count)
                logger.info(f"Processing pages {chunk_start + 1} to {chunk_end}")

                # Convert and process chunk
                chunk_data = await self._process_page_chunk(pdf_path, chunk_start, chunk_end, schema)
                extracted_data.extend(chunk_data)

                # Force garbage collection between chunks
                import gc
                gc.collect()

            # Merge data from all pages
            final_data = self._merge_page_data(extracted_data, schema)

            # Fill missing fields with "N/A"
            if schema:
                final_data = self._fill_missing_fields(final_data, schema)

            return {
                "success": True,
                "data": final_data,
                "page_count": page_count,
                "confidence_scores": self._calculate_confidence(extracted_data)
            }
            
        except Exception as e:
            logger.error(f"Error processing PDF: {str(e)}")
            return {
                "success": False,
                "error": str(e),
                "data": {}
            }
    
    def _get_page_count(self, pdf_path: str) -> int:
        """Get the number of pages in a PDF without loading all images"""
        try:
            import fitz  # PyMuPDF
            doc = fitz.open(pdf_path)
            count = len(doc)
            doc.close()
            return count
        except ImportError:
            # Fallback to pdf2image if PyMuPDF not available
            from pdf2image.exceptions import PDFInfoNotInstalledError
            try:
                import subprocess
                result = subprocess.run(['pdfinfo', pdf_path], capture_output=True, text=True)
                for line in result.stdout.split('\n'):
                    if line.startswith('Pages:'):
                        return int(line.split(':')[1].strip())
            except (subprocess.SubprocessError, FileNotFoundError):
                pass
            # Final fallback - convert first page to get info
            images = convert_from_path(pdf_path, dpi=150, first_page=1, last_page=1)
            # Use a rough estimate based on file size if we can't get exact count
            return max(1, len(images))

    async def _process_page_chunk(self, pdf_path: str, start_page: int, end_page: int, schema: Optional[Dict]) -> List[Dict]:
        """Process a chunk of pages with memory optimization"""
        try:
            # Convert only the required pages with reduced DPI for memory efficiency
            images = convert_from_path(
                pdf_path,
                dpi=200,  # Reduced from 300 to save memory
                first_page=start_page + 1,  # pdf2image uses 1-based indexing
                last_page=end_page
            )

            chunk_data = []
            for i, image in enumerate(images):
                page_num = start_page + i + 1
                logger.info(f"Processing page {page_num}")

                # Optimize image size if too large
                image = self._optimize_image_size(image)

                # Enhance image quality
                enhanced_image = self.preprocessing.enhance(image)

                # Extract data using GPT-4o
                page_data = await self._extract_with_gpt4o(enhanced_image, schema)
                page_data['page_number'] = page_num
                chunk_data.append(page_data)

                # Clear image from memory
                del image, enhanced_image

            return chunk_data

        except Exception as e:
            logger.error(f"Error processing page chunk {start_page}-{end_page}: {str(e)}")
            raise

    def _optimize_image_size(self, image: Image.Image, max_dimension: int = 2048) -> Image.Image:
        """Optimize image size to prevent memory issues"""
        width, height = image.size

        # If image is too large, resize it
        if width > max_dimension or height > max_dimension:
            # Calculate new size maintaining aspect ratio
            if width > height:
                new_width = max_dimension
                new_height = int((height * max_dimension) / width)
            else:
                new_height = max_dimension
                new_width = int((width * max_dimension) / height)

            image = image.resize((new_width, new_height), Image.Resampling.LANCZOS)
            logger.info(f"Resized image from {width}x{height} to {new_width}x{new_height}")

        return image
    
    async def _extract_with_gpt4o(self, image: Image.Image, schema: Optional[Dict] = None) -> Dict:
        """Extract data from image using GPT-4o vision capabilities"""
        # Convert image to base64
        import io
        buffered = io.BytesIO()
        image.save(buffered, format="PNG")
        image_base64 = base64.b64encode(buffered.getvalue()).decode()
        
        # Build prompt
        prompt = self._build_extraction_prompt(schema)
        
        try:
            # Use sync client since OpenAI doesn't have async support
            import asyncio
            loop = asyncio.get_event_loop()
            response = await loop.run_in_executor(
                None,
                lambda: self.openai_client.chat.completions.create(
                    model=settings.OPENAI_MODEL,
                    messages=[
                        {
                            "role": "user",
                            "content": [
                                {"type": "text", "text": prompt},
                                {
                                    "type": "image_url",
                                    "image_url": {
                                        "url": f"data:image/png;base64,{image_base64}"
                                    }
                                }
                            ]
                        }
                    ],
                    max_tokens=4096,
                    temperature=0.1
                )
            )
            
            # Parse the response
            content = response.choices[0].message.content
            try:
                return json.loads(content)
            except json.JSONDecodeError:
                # Fallback to structured extraction
                return self._parse_unstructured_response(content)
                
        except Exception as e:
            logger.error(f"OpenAI API error: {str(e)}")
            # Fallback to OCR
            return self._fallback_ocr_extraction(image)
    
    def _build_extraction_prompt(self, schema: Optional[Dict] = None) -> str:
        """Build the extraction prompt for GPT-4o"""
        if schema:
            fields_description = json.dumps(schema, indent=2)
            return f"""
            Analyze this document image and extract all data according to this schema:
            {fields_description}
            
            Rules:
            1. Extract all visible text and data from the document
            2. Match extracted data to the schema fields
            3. For any missing or unreadable fields, use "N/A"
            4. Return the data as valid JSON matching the schema structure
            5. Include confidence scores for each field (0-1)
            
            Return only the JSON data, no explanations.
            """
        else:
            return """
            Analyze this document and extract all visible information.
            Identify the document type and all fields present.
            
            Return as JSON with this structure:
            {
                "document_type": "detected type",
                "fields": {
                    "field_name": "value",
                    ...
                },
                "confidence": {
                    "field_name": 0.95,
                    ...
                }
            }
            """
    
    def _merge_page_data(self, page_data: List[Dict], schema: Optional[Dict] = None) -> Dict:
        """Merge data from multiple pages into a single record"""
        if not page_data:
            return {}
            
        # For single page, return as is
        if len(page_data) == 1:
            return page_data[0].get('fields', page_data[0])
            
        # For multiple pages, intelligently merge
        merged = {}
        for page in page_data:
            fields = page.get('fields', page)
            for key, value in fields.items():
                if key not in merged or merged[key] == "N/A":
                    merged[key] = value
                    
        return merged
    
    def _fill_missing_fields(self, data: Dict, schema: Dict) -> Dict:
        """Fill missing fields with 'N/A'"""
        for field in schema.get('required_fields', []):
            if field not in data or not data[field]:
                data[field] = "N/A"
        return data
    
    def _calculate_confidence(self, extracted_data: List[Dict]) -> Dict:
        """Calculate average confidence scores"""
        all_scores = {}
        for page in extracted_data:
            confidence = page.get('confidence', {})
            for field, score in confidence.items():
                if field not in all_scores:
                    all_scores[field] = []
                all_scores[field].append(score)
                
        # Average scores
        avg_scores = {}
        for field, scores in all_scores.items():
            avg_scores[field] = sum(scores) / len(scores) if scores else 0.0
            
        return avg_scores
    
    def _fallback_ocr_extraction(self, image: Image.Image) -> Dict:
        """Fallback to Tesseract OCR if GPT-4o fails"""
        try:
            text = pytesseract.image_to_string(image)
            return {
                "raw_text": text,
                "fields": {},
                "extraction_method": "ocr_fallback"
            }
        except Exception as e:
            logger.error(f"OCR fallback failed: {str(e)}")
            return {"error": "extraction_failed"}
    
    def _parse_unstructured_response(self, content: str) -> Dict:
        """Parse unstructured text response into dictionary"""
        # Simple key-value extraction
        result = {}
        lines = content.strip().split('\n')
        for line in lines:
            if ':' in line:
                key, value = line.split(':', 1)
                result[key.strip()] = value.strip()
        return result


class ImagePreprocessor:
    """Enhance scanned document images for better OCR/AI processing"""
    
    def enhance(self, image: Image.Image) -> Image.Image:
        """Apply enhancement pipeline to improve image quality"""
        # Convert PIL to OpenCV
        cv_image = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2BGR)
        
        # Apply enhancements
        cv_image = self._deskew(cv_image)
        cv_image = self._remove_noise(cv_image)
        cv_image = self._enhance_contrast(cv_image)
        cv_image = self._sharpen(cv_image)
        
        # Convert back to PIL
        return Image.fromarray(cv2.cvtColor(cv_image, cv2.COLOR_BGR2RGB))
    
    def _deskew(self, image: np.ndarray) -> np.ndarray:
        """Correct image skew"""
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        edges = cv2.Canny(gray, 50, 150, apertureSize=3)
        lines = cv2.HoughLines(edges, 1, np.pi/180, 200)
        
        if lines is not None:
            angles = []
            for rho, theta in lines[:, 0]:
                angle = (theta * 180 / np.pi) - 90
                if -45 <= angle <= 45:
                    angles.append(angle)
                    
            if angles:
                median_angle = np.median(angles)
                if abs(median_angle) > 0.5:
                    (h, w) = image.shape[:2]
                    center = (w // 2, h // 2)
                    M = cv2.getRotationMatrix2D(center, median_angle, 1.0)
                    image = cv2.warpAffine(image, M, (w, h), 
                                         flags=cv2.INTER_CUBIC,
                                         borderMode=cv2.BORDER_REPLICATE)
        return image
    
    def _remove_noise(self, image: np.ndarray) -> np.ndarray:
        """Remove noise from scanned document"""
        return cv2.fastNlMeansDenoisingColored(image, None, 10, 10, 7, 21)
    
    def _enhance_contrast(self, image: np.ndarray) -> np.ndarray:
        """Enhance contrast using CLAHE"""
        lab = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)
        l, a, b = cv2.split(lab)
        clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8, 8))
        l = clahe.apply(l)
        enhanced = cv2.merge([l, a, b])
        return cv2.cvtColor(enhanced, cv2.COLOR_LAB2BGR)
    
    def _sharpen(self, image: np.ndarray) -> np.ndarray:
        """Sharpen text in the image"""
        kernel = np.array([[-1,-1,-1],
                           [-1, 9,-1],
                           [-1,-1,-1]])
        return cv2.filter2D(image, -1, kernel)