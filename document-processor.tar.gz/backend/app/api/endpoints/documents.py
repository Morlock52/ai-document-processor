import os
import hashlib
import asyncio
import io
from typing import List, Optional
from datetime import datetime

from fastapi import APIRouter, UploadFile, File, HTTPException, Depends, Query
from fastapi.responses import StreamingResponse, JSONResponse
from sqlalchemy.orm import Session
import aiofiles
from typing import Dict, Any

from app.db.database import get_db
from app.models.document import Document, ProcessingStatus
from app.schemas.document import (
    DocumentResponse, 
    DocumentListResponse,
    ProcessingStatusResponse,
    DocumentProcessRequest
)
from app.services.document_processor import DocumentProcessor
from app.services.excel_exporter import ExcelExporter
from app.services.s3_service import S3Service
from app.core.config import settings
from app.utils.background_tasks import enqueue_document_processing, get_job_status

router = APIRouter()

@router.post("/upload", response_model=DocumentResponse)
async def upload_document(
    file: UploadFile = File(...),
    db: Session = Depends(get_db)
):
    """Upload a PDF document for processing"""
    # Validate file
    if not file.filename.lower().endswith('.pdf'):
        raise HTTPException(status_code=400, detail="Only PDF files are allowed")
    
    if file.size > settings.MAX_UPLOAD_SIZE:
        raise HTTPException(status_code=400, detail=f"File size exceeds {settings.MAX_UPLOAD_SIZE} bytes")
    
    # Generate unique filename
    file_hash = hashlib.md5(file.filename.encode()).hexdigest()
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    unique_filename = f"{timestamp}_{file_hash}.pdf"
    
    # Save file locally first
    local_path = os.path.join(settings.UPLOAD_DIR, unique_filename)
    os.makedirs(settings.UPLOAD_DIR, exist_ok=True)
    
    async with aiofiles.open(local_path, 'wb') as f:
        content = await file.read()
        await f.write(content)
    
    # Create database record
    document = Document(
        filename=unique_filename,
        original_filename=file.filename,
        file_size=file.size,
        file_hash=file_hash,
        status=ProcessingStatus.PENDING
    )
    
    db.add(document)
    db.commit()
    db.refresh(document)
    
    # Upload to S3 if configured
    if settings.AWS_ACCESS_KEY_ID:
        s3_service = S3Service()
        s3_key = f"uploads/{unique_filename}"
        await s3_service.upload_file(local_path, s3_key)
        document.s3_key = s3_key
        db.commit()
    
    return DocumentResponse.from_orm(document)

@router.post("/process/{document_id}", response_model=Dict[str, Any])
async def process_document(
    document_id: int,
    request: DocumentProcessRequest = None,
    db: Session = Depends(get_db)
):
    """Start processing a document using RQ"""
    # Get document
    document = db.query(Document).filter(Document.id == document_id).first()
    if not document:
        raise HTTPException(status_code=404, detail="Document not found")
    
    # Check if document is already being processed
    if document.status == ProcessingStatus.PROCESSING:
        return JSONResponse(
            status_code=200,
            content={
                "document_id": document_id,
                "status": document.status.value,
                "progress": document.progress,
                "message": "Document is already being processed"
            }
        )
    
    try:
        # Enqueue the processing task
        job_id = enqueue_document_processing(
            document_id=document_id,
            schema=request.schema if request else None
        )
        
        # Update document status
        document.status = ProcessingStatus.PROCESSING
        document.progress = 0.0
        document.job_id = job_id
        db.commit()
        
        return {
            "job_id": job_id,
            "document_id": document_id,
            "status": "queued",
            "message": "Document processing queued"
        }
        
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Failed to enqueue document processing: {str(e)}")

@router.get("/jobs/{job_id}", response_model=Dict[str, Any])
async def get_job_status_endpoint(job_id: str):
    """Get the status of a background job"""
    return get_job_status(job_id)

@router.get("/{document_id}/status", response_model=ProcessingStatusResponse)
async def get_processing_status(
    document_id: int,
    db: Session = Depends(get_db)
):
    """Get the processing status of a document"""
    document = db.query(Document).filter(Document.id == document_id).first()
    if not document:
        raise HTTPException(status_code=404, detail="Document not found")
    
    return ProcessingStatusResponse(
        document_id=document.id,
        status=document.status,
        progress=document.progress,
        error_message=document.error_message,
        page_count=document.page_count,
        processing_time=document.processing_time,
        extracted_data=document.extracted_data
    )

@router.get("/{document_id}/download/excel")
async def download_excel(
    document_id: int,
    include_metadata: bool = Query(True, description="Include metadata sheet"),
    db: Session = Depends(get_db)
):
    """Download extracted data as Excel file"""
    document = db.query(Document).filter(Document.id == document_id).first()
    if not document:
        raise HTTPException(status_code=404, detail="Document not found")
    
    if document.status != ProcessingStatus.COMPLETED:
        raise HTTPException(status_code=400, detail="Document processing not completed")
    
    if not document.extracted_data:
        raise HTTPException(status_code=400, detail="No data available for export")
    
    # Export to Excel
    exporter = ExcelExporter()
    excel_data = await exporter.export_to_excel(
        [document.extracted_data],
        include_metadata=include_metadata
    )
    
    # Update export timestamp
    document.excel_exported_at = datetime.utcnow()
    db.commit()
    
    # Return file
    filename = f"{document.original_filename.replace('.pdf', '')}_extracted.xlsx"
    return StreamingResponse(
        io.BytesIO(excel_data),
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f"attachment; filename={filename}"}
    )

@router.get("/", response_model=DocumentListResponse)
async def list_documents(
    skip: int = Query(0, ge=0),
    limit: int = Query(10, ge=1, le=100),
    status: Optional[ProcessingStatus] = None,
    db: Session = Depends(get_db)
):
    """List all documents with pagination"""
    query = db.query(Document)
    
    if status:
        query = query.filter(Document.status == status)
    
    total = query.count()
    documents = query.offset(skip).limit(limit).all()
    
    return DocumentListResponse(
        total=total,
        documents=[DocumentResponse.from_orm(doc) for doc in documents],
        skip=skip,
        limit=limit
    )

@router.delete("/{document_id}")
async def delete_document(
    document_id: int,
    db: Session = Depends(get_db)
):
    """Delete a document and its associated files"""
    document = db.query(Document).filter(Document.id == document_id).first()
    if not document:
        raise HTTPException(status_code=404, detail="Document not found")
    
    # Delete local file
    local_path = os.path.join(settings.UPLOAD_DIR, document.filename)
    if os.path.exists(local_path):
        os.remove(local_path)
    
    # Delete from S3
    if document.s3_key and settings.AWS_ACCESS_KEY_ID:
        s3_service = S3Service()
        await s3_service.delete_file(document.s3_key)
    
    # Delete from database
    db.delete(document)
    db.commit()
    
    return {"message": "Document deleted successfully"}

@router.post("/batch-process", response_model=Dict[str, Any])
async def batch_process_documents(
    document_ids: List[int],
    schema: Optional[dict] = None,
    db: Session = Depends(get_db)
):
    """Process multiple documents in batch using RQ"""
    if not document_ids:
        raise HTTPException(status_code=400, detail="No document IDs provided")
    
    # Get documents
    documents = db.query(Document).filter(Document.id.in_(document_ids)).all()
    if len(documents) != len(document_ids):
        found_ids = {doc.id for doc in documents}
        not_found = [doc_id for doc_id in document_ids if doc_id not in found_ids]
        raise HTTPException(status_code=404, detail=f"Documents not found: {not_found}")
    
    job_ids = []
    
    # Start processing each document
    for doc in documents:
        if doc.status != ProcessingStatus.PROCESSING:
            try:
                job_id = enqueue_document_processing(
                    document_id=doc.id,
                    schema=schema
                )
                doc.status = ProcessingStatus.PROCESSING
                doc.progress = 0.0
                doc.job_id = job_id
                job_ids.append(job_id)
            except Exception as e:
                logger.error(f"Failed to enqueue document {doc.id}: {str(e)}")
    
    db.commit()
    
    return {
        "status": "queued",
        "message": f"Queued {len(job_ids)} documents for processing",
        "job_ids": job_ids,
        "document_ids": [doc.id for doc in documents if doc.status == ProcessingStatus.PROCESSING]
    }

@router.get("/batch/download/excel")
async def batch_download_excel(
    document_ids: List[int] = Query(..., description="List of document IDs"),
    db: Session = Depends(get_db)
):
    """Download multiple documents as a single Excel file"""
    documents = db.query(Document).filter(
        Document.id.in_(document_ids),
        Document.status == ProcessingStatus.COMPLETED
    ).all()
    
    if not documents:
        raise HTTPException(status_code=404, detail="No completed documents found")
    
    # Collect all extracted data
    all_data = []
    for doc in documents:
        if doc.extracted_data:
            data = doc.extracted_data.copy()
            data['_source_document'] = doc.original_filename
            all_data.append(data)
    
    if not all_data:
        raise HTTPException(status_code=400, detail="No data available for export")
    
    # Export to Excel
    exporter = ExcelExporter()
    excel_data = await exporter.export_batch(all_data)
    
    # Return file
    filename = f"batch_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    return StreamingResponse(
        io.BytesIO(excel_data),
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f"attachment; filename={filename}"}
    )