from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.db.database import get_db
from app.core.config import settings

router = APIRouter()

@router.get("/health")
async def health_check():
    """Basic health check endpoint"""
    return {
        "status": "healthy",
        "version": settings.VERSION,
        "service": "Document Processor API"
    }

@router.get("/health/detailed")
async def detailed_health_check(db: Session = Depends(get_db)):
    """Detailed health check including database connectivity"""
    health_status = {
        "status": "healthy",
        "version": settings.VERSION,
        "checks": {
            "database": "unknown",
            "openai": "unknown",
            "s3": "unknown"
        }
    }
    
    # Check database
    try:
        db.execute("SELECT 1")
        health_status["checks"]["database"] = "healthy"
    except Exception as e:
        health_status["checks"]["database"] = f"unhealthy: {str(e)}"
        health_status["status"] = "degraded"
    
    # Check OpenAI API key
    if settings.OPENAI_API_KEY:
        health_status["checks"]["openai"] = "configured"
    else:
        health_status["checks"]["openai"] = "not configured"
        health_status["status"] = "degraded"
    
    # Check S3 configuration
    if settings.AWS_ACCESS_KEY_ID and settings.AWS_SECRET_ACCESS_KEY:
        health_status["checks"]["s3"] = "configured"
    else:
        health_status["checks"]["s3"] = "not configured"
    
    return health_status