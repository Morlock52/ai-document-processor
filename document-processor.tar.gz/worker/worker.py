import os
import logging
import sys
from pathlib import Path

# Add the backend directory to the Python path
sys.path.insert(0, str(Path(__file__).parent.parent / 'backend'))

from redis import Redis
from rq import Worker, Queue, Connection
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def start_worker():
    # Get Redis URL from environment variables
    redis_url = os.getenv('REDIS_URL', 'redis://redis:6379/0')
    logger.info(f"Connecting to Redis at {redis_url}")
    
    # Initialize Redis connection
    redis_conn = Redis.from_url(redis_url)
    
    # Verify Redis connection
    try:
        redis_conn.ping()
        logger.info("Successfully connected to Redis")
    except Exception as e:
        logger.error(f"Failed to connect to Redis: {e}")
        raise
    
    # Define the queue
    queue = Queue(connection=redis_conn)
    
    # Start the worker
    with Connection(redis_conn):
        worker = Worker([queue])
        logger.info("Starting RQ worker...")
        worker.work()

if __name__ == '__main__':
    try:
        start_worker()
    except Exception as e:
        logger.exception("Worker failed")
        sys.exit(1)
