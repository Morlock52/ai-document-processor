import axios from 'axios';

// Use relative URL to work with any port configuration
const API_BASE_URL = '/api/v1';

export const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Document API
export const documentApi = {
  upload: async (file: File) => {
    const formData = new FormData();
    formData.append('file', file);
    
    const response = await api.post('/documents/upload', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
    
    return response.data;
  },

  process: async (documentId: number, schema?: unknown) => {
    const response = await api.post(`/documents/process/${documentId}`, { schema });
    return response.data;
  },

  getStatus: async (documentId: number) => {
    const response = await api.get(`/documents/${documentId}/status`);
    return response.data;
  },

  list: async (params?: { skip?: number; limit?: number; status?: string }) => {
    const response = await api.get('/documents/', { params });
    return response.data;
  },

  downloadExcel: async (documentId: number, includeMetadata: boolean = true) => {
    const response = await api.get(`/documents/${documentId}/download/excel`, {
      params: { include_metadata: includeMetadata },
      responseType: 'blob',
    });
    
    return response.data;
  },

  delete: async (documentId: number) => {
    const response = await api.delete(`/documents/${documentId}`);
    return response.data;
  },

  batchProcess: async (documentIds: number[], schema?: unknown) => {
    const response = await api.post('/documents/batch/process', {
      document_ids: documentIds,
      schema,
    });
    return response.data;
  },

  batchDownloadExcel: async (documentIds: number[]) => {
    const response = await api.get('/documents/batch/download/excel', {
      params: { document_ids: documentIds },
      responseType: 'blob',
    });
    
    return response.data;
  },
};

// Schema API
export const schemaApi = {
  detect: async (sampleImageBase64: string, description?: string) => {
    const response = await api.post('/schemas/detect', {
      sample_image_base64: sampleImageBase64,
      description,
    });
    return response.data;
  },

  list: async () => {
    const response = await api.get('/schemas/');
    return response.data;
  },

  save: async (schema: unknown) => {
    const response = await api.post('/schemas/', schema);
    return response.data;
  },
};

// SSE for real-time updates
export const createEventSource = (documentId: number) => {
  return new EventSource(`${API_BASE_URL}/documents/${documentId}/stream`);
};